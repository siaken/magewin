
enum PORT_TYPE {
	COM,
	MA101,
	MA111,
};

static const DWORD BRTBL_BRIDGE[] = {
	4800,
	9600,
	19200,
	38400,
	51200,
	57600,
	102400,
	115200,
};

static const DWORD BRTBL_COM[] = {
	1200,
	2400,
	4800,
	9600,
	14400,
	19200,
	38400,
	57600,
	115200,
};

static const DWORD CHECKRATE_BRIDGE[] = {
	4800,
	9600,
};

static const DWORD CHECKRATE_COM[] = {
	1200,
	2400,
	4800,
	9600,
};
//=====struct define=====//
struct BODYINFO {
	TCHAR		*name;
	DWORD		type;
	DWORD		setver;
	DWORD		flashsize;
	DWORD		iaplb;
	UINT		orsize;
	struct {
		TCHAR	*ENname;
		TCHAR	*SCname;
	} or[8];
};

struct DOWNLOADINFO {
	UINT		porttype;
	HANDLE		comphandle;
	DWORD		checkrate;
	DWORD		baudrate;
	UINT		body;
	BYTE		or;
	BYTE		options;
	PBYTE		buffer;
	DWORD		buffersize;
	PWORD		state;
};

//=====chip type define=====//
#define TYPE_32SERIES		(0x01 << 0)
#define TYPE_31SERIES		(0x01 << 1)
static const CString TypeName[] = {
	_T("32 Series"),
	_T("31 Series"),
};
//=====setver define=====//
#define SETVER_DEF			0x00000000
#define SETVER_FIXBR_115200	0x00000001
//=====result define=====//
#define SUCCESS						0x0065
#define FAIL						0x0066
#define USER_STOP					0x0067
#define NOT_FIND_DEVICE				0x0068
#define CUSTOMER_ID_ERROR			0x0069
#define DEVICE_ID_ERROR				0x006A
#define BAUDRATE_TOO_LARGE			0x006B
#define SET_SYNC_ERROR				0x006C
#define WRITE_OR_ERROR				0x006D
#define ERASE_ERROR					0x006E
#define REGISTER_ERROR				0x006F
#define PROGRAM_ERROR				0x0070
#define DUMPINFO_ERROR				0x0071
#define FUNCTION_NOT_SUPPORT		0x0072
//=====functions=====//
VOID __stdcall GetDLLInfo(DWORD* dllver);
UINT __stdcall GetBodyInfo(BODYINFO** info);
WORD __stdcall DumpInfo(DOWNLOADINFO* info);
WORD __stdcall UpdateMCU(DOWNLOADINFO* info, BOOL askLock);	//askLock = FALSE�A�bIC LOCK �ɴN���|�ݬO�_�n�W��F 