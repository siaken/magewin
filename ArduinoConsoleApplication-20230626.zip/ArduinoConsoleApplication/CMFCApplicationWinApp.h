#pragma once
#include <afxwin.h>

class CMFCApplicationWinApp :public CWinApp
{
public:
    CMFCApplicationWinApp();

public:
    virtual BOOL InitInstance();
    DECLARE_MESSAGE_MAP()
        afx_msg void OnIdhelp();
    afx_msg void OnVsVersionInfo();
    virtual int ExitInstance();
};





