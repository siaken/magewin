﻿// cdispp.cpp: 实现文件
//

#include "afxdialogex.h"
#include "cdispp.h"
#include "resource.h"


// cdispp 对话框

IMPLEMENT_DYNAMIC(cdispp, CDialogEx)

cdispp::cdispp(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)
{

}

cdispp::~cdispp()
{

}


void cdispp::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);

    DDX_Control(pDX, IDC_STATIC_Dis, m_DisString);
}


BEGIN_MESSAGE_MAP(cdispp, CDialogEx)
	ON_MESSAGE(WM_MYMESSAGE_UPLEVEL,  OnUpLevel)
	ON_MESSAGE(WM_MYMESSAGE_DOWNLEVEL, OnDownLevel)
END_MESSAGE_MAP()


// cdispp 消息处理程序

afx_msg LRESULT  cdispp::OnUpLevel(WPARAM wParam, LPARAM lParam)
{
	return 0;
}
afx_msg LRESULT  cdispp::OnDownLevel(WPARAM wParam, LPARAM lParam)
{
	return 0;
}
