
#include "Megawin_UploadClass.h"

#include "CMFCApplicationWinApp.h"

#include "cdispp.h"
#include "resource.h"

extern "C" {
#include "hidsdi.h"
#include "setupapi.h"
}

cdispp    g_cDisDlg;
DWORD WINAPI Thread_Display(LPVOID pParam)
{
    Megawin_UploadClass*  pCMegawin = (Megawin_UploadClass*)pParam;

    pCMegawin->m_isDisTheadRun = 0;
    CMFCApplicationWinApp* cwa = new CMFCApplicationWinApp;
    AfxWinInit(GetModuleHandleW(nullptr), nullptr, GetCommandLineW(), 1);

    pCMegawin->m_isDisTheadRun = 1;
    if (cwa->InitInstance())
    {
        pCMegawin->m_isDisTheadRun = 1;
        cwa->Run();
    }
    pCMegawin->m_isDisTheadRun = 0;
    return 0;
}


typedef struct                          // Structure of Megawin HID device 
{
    WORD VID;                          // Vendor ID
    WORD PID;                          // Product ID
    HANDLE Handle;                     // Device handle which get from CreateFile
    BYTE UnitSize;                     // Feature report size
    BYTE InputReportSize;              // Interrupt In report size
    BYTE OutputReportSize;             // Interrupt Out report size
} MWHID;

MWHID Mwhid;

const int EDIT_BUFFER_SIZE = 0x21;

void Megawin_UploadClass::HID_DeInit()
{
    if ((Mwhid.Handle != INVALID_HANDLE_VALUE) && (Mwhid.Handle != NULL))
    {
        CloseHandle(Mwhid.Handle);
        Mwhid.Handle = NULL;
    }
}

void Megawin_UploadClass::HID_SendResetCMD()
{
    BOOL bResult;
    BYTE Buffer[EDIT_BUFFER_SIZE];

    if ((Mwhid.Handle != INVALID_HANDLE_VALUE) && (Mwhid.Handle != NULL))
    {
        memset(Buffer,  0 ,  sizeof(Buffer) );
        Buffer[0] = 0x00;
        Buffer[1] = 0x55;
        Buffer[2] = 0x32;
        Buffer[3] = 0x01;
        Buffer[4] = 0x08;
        Buffer[5] = 0x00;
        Buffer[6] = 0x00;
        Buffer[7] = 0x00;
        bResult = HidD_SetFeature(  Mwhid.Handle,
                                    Buffer,
                                    Mwhid.UnitSize );
    }
}

DWORD Megawin_UploadClass::HID_CreateDevice(WORD VID, WORD PID)
{
    static GUID HidGuid;                         // HID Globally Unique ID: windows supplies us with this value
    HDEVINFO HidDevInfo;                         // handle to structure containing all attached HID Device information
    SP_DEVICE_INTERFACE_DATA devInfoData;        // Information structure for HID devices
    BOOLEAN Result;                              // result of getting next device information structure
    DWORD Index;                                 // index of HidDevInfo array entry
    DWORD DataSize;                              // size of the DeviceInterfaceDetail structure
    PSP_DEVICE_INTERFACE_DETAIL_DATA detailData = NULL; // device info data
    DWORD RequiredSize;                          // size of device info data structure
    BOOLEAN DIDResult;                           // get device info data result
    HIDD_ATTRIBUTES HIDAttrib;                   // HID device attributes
    HIDP_CAPS Capabilities;
    PHIDP_PREPARSED_DATA HidParsedData;
    BOOL bFind = FALSE;

    Mwhid.VID = VID;
    Mwhid.PID = PID;
    Mwhid.Handle = NULL;
    Mwhid.UnitSize = 0;

    int i = 0;
    // 1) Get the HID Globally Unique ID from the OS 
    HidD_GetHidGuid(&HidGuid);

    // 2) Get an array of structures containing information about all attached and enumerated HIDs
    HidDevInfo = SetupDiGetClassDevs(&HidGuid, NULL, NULL, DIGCF_PRESENT | DIGCF_INTERFACEDEVICE);


    // 3) Step through the attached device list 1 by 1 and examine
    //    each of the attached devices.  When there are no more entries in
    //    the array of structures, the function will return FALSE.

    // init to first index of array 
    Index = 0;

    // set to the size of the structure that will contain the device info data
    devInfoData.cbSize = sizeof(devInfoData);

    // Get information about the HID device with the 'Index' array entry
    do {
        Result = SetupDiEnumDeviceInterfaces(HidDevInfo,
            0,
            &HidGuid,
            Index,
            &devInfoData);

        // If we run into this condition, then there are no more entries
        // to examine, we might as well return FALSE at point
        if (Result == FALSE)
        { // free the memory allocated for DetailData
            if (detailData != NULL)
                free(detailData);

            // free HID device info list resources
            SetupDiDestroyDeviceInfoList(HidDevInfo);

            return FALSE;
        }

        // 3) Get the size of the DEVICE_INTERFACE_DETAIL_DATA
        //    structure.  The first call will return an error condition,
        //    but we'll get the size of the strucure
        DIDResult = SetupDiGetDeviceInterfaceDetail(HidDevInfo,
            &devInfoData,
            NULL,
            0,
            &DataSize,
            NULL);
        // allocate memory for the HidDevInfo structure
        detailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(DataSize);

        // set the size parameter of the structure
        detailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

        // 4) Now call the function with the correct size parameter.  This 
        //    function will return data from one of the array members that 
        //    Step #2 pointed to.  This way we can start to identify the
        //    attributes of particular HID devices.
        DIDResult = SetupDiGetDeviceInterfaceDetail(HidDevInfo,
            &devInfoData,
            detailData,
            DataSize,
            &RequiredSize,
            NULL);

        // 5) Open a file handle to the device.  Make sure the
        //    attibutes specify overlapped transactions or the IN
        //    transaction may block the input thread.
        Mwhid.Handle = CreateFile(detailData->DevicePath,
            GENERIC_READ | GENERIC_WRITE,
            //                                    0,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            NULL,
            OPEN_EXISTING,
            //                                    FILE_FLAG_OVERLAPPED ,
            0,
            NULL);

        if (Mwhid.Handle == INVALID_HANDLE_VALUE) // Only for Keyboard
        {
            Mwhid.Handle = CreateFile(detailData->DevicePath,
                //                                        GENERIC_READ | GENERIC_WRITE ,
                0,
                FILE_SHARE_READ | FILE_SHARE_WRITE,
                NULL,
                OPEN_EXISTING,
                //                                        FILE_FLAG_OVERLAPPED ,
                0,
                NULL);
        }
        // 6) Get the Device VID & PID to see if it's the device we want
        if (Mwhid.Handle != INVALID_HANDLE_VALUE)
        {
            HIDAttrib.Size = sizeof(HIDAttrib);
            HidD_GetAttributes(Mwhid.Handle, &HIDAttrib);

            if ((HIDAttrib.VendorID == Mwhid.VID) && (HIDAttrib.ProductID == Mwhid.PID))
            {
                // get a handle to a buffer that describes the device's capabilities.  This
                // line plus the following two lines of code extract the report length the
                // device is claiming to support
                // found HID device
                HidD_GetPreparsedData(Mwhid.Handle, &HidParsedData);

                // extract the capabilities info
                HidP_GetCaps(HidParsedData, &Capabilities);

                // Free the memory allocated when getting the preparsed data
                HidD_FreePreparsedData(HidParsedData);

                if (Capabilities.FeatureReportByteLength > 0)
                {
                    Mwhid.UnitSize = (BYTE)Capabilities.FeatureReportByteLength;
                    Mwhid.InputReportSize = (BYTE)Capabilities.InputReportByteLength;
                    Mwhid.OutputReportSize = (BYTE)Capabilities.OutputReportByteLength;
                    bFind = TRUE;
                }
                if (bFind == TRUE)
                {
                    // free the memory allocated for DetailData
                    if (detailData != NULL)
                        free(detailData);

                    // free HID device info list resources
                    SetupDiDestroyDeviceInfoList(HidDevInfo);

                    return TRUE;
                }
            }
            else
            {
                // 7) Close the Device Handle because we didn't find the device
                //    with the correct VID and PID 
                CloseHandle(Mwhid.Handle);
                if (detailData != NULL)
                {
                    free(detailData);
                    detailData = NULL;
                }
            }
        }
        // increment the array index to search the next entry
        Index++;

    } while (Result == TRUE);

    // free the memory allocated for DetailData
    if (detailData != NULL)
    {
        free(detailData);
        detailData = NULL;
    }
    // free HID device info list resources
    SetupDiDestroyDeviceInfoList(HidDevInfo);

    return FALSE;
}



Megawin_UploadClass::Megawin_UploadClass()
{
    m_loadfileaddress = 0;

    m_loadFileName = "";
    m_MCUName = "";
    m_PortName = "";

    m_pstbodyinfo = NULL;
    m_bodycount = 0;
    m_pstdownloadinfo = NULL;

    m_pstdownloadinfo = new DOWNLOADINFO;
    if (m_pstdownloadinfo == NULL)
    {
        return;
    }

    m_pstdownloadinfo->body = -1;
    m_pstdownloadinfo-> or = 0x00;
    m_pstdownloadinfo->options = 0x00;
    m_pstdownloadinfo->state = new WORD;
    if (m_pstdownloadinfo->state == NULL)
    {
        return;
    }
    *(m_pstdownloadinfo->state) = WORD(-1);

    m_DisThread = NULL;
    m_UseDlg = 0;
    m_isDisTheadRun = 0;
}

Megawin_UploadClass::~Megawin_UploadClass()
{
    m_loadFileName = "";
    m_MCUName = "";
    m_PortName = "";

    m_pstbodyinfo = NULL;
/*
    if (m_pstbodyinfo != NULL)
    {
        delete[] m_pstbodyinfo;
        m_pstbodyinfo = NULL;
    }
*/

    if (m_pstdownloadinfo != NULL)
    {
        if ((m_pstdownloadinfo->porttype == COM)
            && (m_pstdownloadinfo->comphandle != NULL))
        {
            CloseHandle(m_pstdownloadinfo->comphandle);
            m_pstdownloadinfo->comphandle = NULL;
        }

        if (m_pstdownloadinfo->buffer != NULL)
        {
            delete[] m_pstdownloadinfo->buffer;
            m_pstdownloadinfo->buffer = NULL;
        }

        if (m_pstdownloadinfo->state != NULL)
        {
            delete m_pstdownloadinfo->state;
            m_pstdownloadinfo->state = NULL;
        }


        delete m_pstdownloadinfo;
        m_pstdownloadinfo = NULL;

        m_DisThread = NULL;
        m_UseDlg = 0;
        m_isDisTheadRun = 0;
    }
}



int Megawin_UploadClass::BodyInit( LPCSTR Filename,  LPCSTR MCUname, LPCSTR PortName)
{
    UINT i;

    m_loadFileName = Filename;
    m_MCUName      = MCUname;
    m_PortName     = PortName;

    m_bodycount = GetBodyInfo(&m_pstbodyinfo);


    for (i = 0; i < m_bodycount; i++)
    {
        if (m_pstbodyinfo[i].name == m_MCUName)
        {
            m_pstdownloadinfo->body = i;
            break;
        }
    }

    m_pstdownloadinfo->options  = 0;
    //External RSTN Cold Reset
    m_pstdownloadinfo->options |= 0x02;

    m_pstdownloadinfo-> or = 0;

    DWORD dllver;
    GetDLLInfo(&dllver);

    return 0;

}

int Megawin_UploadClass::LoadUploadFile(LPCSTR Filename)
{
    m_loadFileName = Filename;


    return 0;
}


int Megawin_UploadClass::DumpInfo()
{
    *(m_pstdownloadinfo->state) = USER_STOP;

    m_pstdownloadinfo->comphandle = NULL;

    m_pstdownloadinfo->porttype = COM;
    m_pstdownloadinfo->comphandle = CreateFile( m_PortName, GENERIC_READ | GENERIC_WRITE,
                                                0, NULL, 
                                                OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 
                                                NULL );
    if (m_pstdownloadinfo->comphandle == INVALID_HANDLE_VALUE) 
    {
        *(m_pstdownloadinfo->state) = FAIL;

        wprintf( L"\r\n Error! open %s error.\r\n", m_PortName.GetString());
        return -1;
    }
    if (m_pstbodyinfo[m_pstdownloadinfo->body].setver == SETVER_FIXBR_115200)
    {
        m_pstdownloadinfo->baudrate = (DWORD)115200;
        m_pstdownloadinfo->checkrate = (DWORD)115200;
    }
    m_pstdownloadinfo->buffersize = 256;
    m_pstdownloadinfo->buffer = new BYTE[m_pstdownloadinfo->buffersize];
    memset(m_pstdownloadinfo->buffer, 0x00, m_pstdownloadinfo->buffersize);

    *(m_pstdownloadinfo->state) = WORD(-1);

//-------CreateThread(NULL, 0, ThreadDumpRun, pParam, 0, &threadid);

//    DumpInfo(m_pstdownloadinfo);

    if (m_pstdownloadinfo->porttype == COM)
    {
        CloseHandle(m_pstdownloadinfo->comphandle);
        m_pstdownloadinfo->comphandle = NULL;
    }
    delete[] m_pstdownloadinfo->buffer;

    return 0;
}


int Megawin_UploadClass::UpdateTarget()
{
    *(m_pstdownloadinfo->state) = USER_STOP;

    m_pstdownloadinfo->comphandle = NULL;

    m_pstdownloadinfo->porttype = COM;
    m_pstdownloadinfo->comphandle = CreateFile( m_PortName, GENERIC_READ | GENERIC_WRITE,
                                                0, NULL,
                                                OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,
                                                NULL);

    if (m_pstdownloadinfo->comphandle == INVALID_HANDLE_VALUE)
    {
        *(m_pstdownloadinfo->state) = FAIL;

        wprintf(L"\r\n Error! open %s error.\r\n", m_PortName.GetString()  );
        return -1;
    }

    if (m_pstbodyinfo[m_pstdownloadinfo->body].setver == SETVER_FIXBR_115200)
    {
        m_pstdownloadinfo->baudrate = (DWORD)115200;
        m_pstdownloadinfo->checkrate = (DWORD)115200;
    }

    wprintf(L"Megawin:Device initialized and ready to accept instructions\r\n");
    wprintf(L"Megawin:Device signature:MG32F02U128\r\n");
    wprintf(L"Megawin:reading input file\"%s\"\r\n", m_loadFileName.GetString());

    //=====Open file=====//
    CFile fp;
    CFileException exception(NULL);
    if (fp.Open(m_loadFileName, CFile::modeRead, &exception) != TRUE)
    {
        wprintf(L"\r\nError!load %s file error.", m_loadFileName.GetString() );
        return -1;
    }
    m_pstdownloadinfo->buffersize = (UINT)fp.GetLength();
    m_pstdownloadinfo->buffer = new BYTE[m_pstdownloadinfo->buffersize];
    fp.Read(m_pstdownloadinfo->buffer, m_pstdownloadinfo->buffersize);
    fp.Close();

    //check size
    if ((m_pstdownloadinfo->buffersize + m_loadfileaddress) > m_pstbodyinfo[m_pstdownloadinfo->body].flashsize)
    {
        wprintf(_T("\r\nError! file size error.") );
        return -1;
    }

    wprintf(L"Megawin:writing flash(%d bytes)\r\n", m_pstdownloadinfo->buffersize);

    HID_CreateDevice(0x0e6a, 0x0331);

    //��������ǰ����һ�θ�λ����
    HID_SendResetCMD();

    DWORD  DisThreadid = 0;
    if (m_UseDlg != 0)
    {
        m_isDisTheadRun = 0;
        if (m_DisThread == NULL)
        {
            m_DisThread = CreateThread(NULL, 0, Thread_Display, this, 0, &DisThreadid);
        }
        while (m_isDisTheadRun == 0)
        {
            Sleep(50);
        }
    }
    else
    {
        m_isDisTheadRun = 0;
        m_DisThread = NULL;
    }


    *(m_pstdownloadinfo->state) = WORD(-1);
    DWORD threadid;
    m_isTheadRun = TRUE;
    m_Thread = CreateThread(NULL, 0, ThreadUpdateRun, this, 0, &threadid);



    DWORD  DTick = ::GetTickCount();
    DWORD  DproTick = ::GetTickCount();
    DWORD  DrstTick = ::GetTickCount();
    DWORD  RstCnt = 0;

    //����һ�θ�λ����
    HID_SendResetCMD();
    ::SetWindowPos(g_cDisDlg.m_hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
    while( m_isTheadRun )
    {
        if (*(m_pstdownloadinfo->state) == WORD(-1))
        {
            if ((RstCnt <= 3) && (GetTickCount() - DrstTick > 5000))
            {
                //��������ǰ����һ�θ�λ����
                HID_SendResetCMD();
                RstCnt++;
                DrstTick = GetTickCount();
            }

            //����������ʱ
            if (RstCnt >= 4)
            {
                HID_DeInit();
                KillDisThread();
                TerminateThread(m_Thread, -1);
                m_Thread = NULL;

                ::MessageBox(0, _T("Time out.\r\nPlease Try again......"), _T("Error."), MB_SYSTEMMODAL);
                m_FunctionResult = FAIL;
                return m_FunctionResult;
            }

            //::MessageBox(0, _T("Please repower DUT...!"), _T("Downloading."), 0); 
            if(m_UseDlg == 0 )
            {
                wprintf(_T("Please repower DUT...!"));
                Sleep(100);
                //Ŀǰ��֧��vt100
                wprintf(_T("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b"));
                Sleep(200);
            }
            else
            {
                if (g_cDisDlg.m_hWnd != NULL)
                {
                    g_cDisDlg.m_DisString.SetWindowText(L"");
                    g_cDisDlg.m_DisString.SendMessage(WM_VSCROLL, SB_BOTTOM);
                    Sleep(100);
                    g_cDisDlg.m_DisString.SetWindowText(L"Auto-Reset Target MCU. Please wait......");
                    g_cDisDlg.m_DisString.SendMessage(WM_VSCROLL, SB_BOTTOM);
                    Sleep(200);
                }
            }
        }
        else
        {
            if (m_UseDlg == 0)
            {
                while ((*(m_pstdownloadinfo->state) <= 100) && (m_isTheadRun))
                {
                    if (GetTickCount() - DTick > 50000)
                    {
                        HID_DeInit();
                        wprintf(_T("Time out!\r\n"));
                        TerminateThread(m_Thread, -1);
                        m_Thread = NULL;
                        m_FunctionResult = FAIL;
                        return m_FunctionResult;
                    }
                    wprintf(_T("#"));
                    Sleep(10);
                }
            }
            else
            {
                //::SetWindowPos(g_cDisDlg.m_hWnd, HWND_TOP, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
                SendMessage(GetDlgItem(g_cDisDlg.m_hWnd, IDC_PROGRESS1), PBM_SETPOS, 0, 0);
                if (g_cDisDlg.m_hWnd != NULL)
                {
                    static WORD laststate = 0;

                    g_cDisDlg.m_DisString.SetWindowText(L"Updating Target MCU. Please wait......");
                    g_cDisDlg.m_DisString.SendMessage(WM_VSCROLL, SB_BOTTOM);

                    while ((*(m_pstdownloadinfo->state) <= 100) && (m_isTheadRun))
                    {
                        if (laststate != *(m_pstdownloadinfo->state))
                        {
                            SendMessage(GetDlgItem(g_cDisDlg.m_hWnd, IDC_PROGRESS1), PBM_SETPOS, *(m_pstdownloadinfo->state), 0);
                            laststate = *(m_pstdownloadinfo->state);
                            DproTick = ::GetTickCount();
                        }
                        else
                        {
                            //��������ʱ
                            if( GetTickCount() - DproTick > 3000 )
                            {
                                HID_DeInit();
                                KillDisThread();
                                TerminateThread(m_Thread, -1);
                                m_Thread = NULL;

                                ::MessageBox(0, _T("Time out.\r\nPlease Try again......"), _T("Error."), MB_SYSTEMMODAL);
                                m_FunctionResult = FAIL;
                                return m_FunctionResult;
                            }
                        }


                        //����������ʱ����ʱ
                        if (GetTickCount() - DTick > 100000)
                        {
                            HID_DeInit();
                            KillDisThread();
                            TerminateThread(m_Thread, -1);
                            m_Thread = NULL;

                            ::MessageBox(0, _T("Time out!"), _T("Error."), MB_SYSTEMMODAL);
                            m_FunctionResult = FAIL;
                            return m_FunctionResult;
                        }
                    }
                }
            }
        }

        //�ȴ���ʱ����ʱ
        if (GetTickCount() - DTick > 100000)
        {
            if (m_UseDlg == 0)
            {
                wprintf(_T("Time out!\r\n"));
            }
            else
            {
                ::MessageBox(0, _T("Time out.\r\nPlease Try again......"), _T("Error."), MB_SYSTEMMODAL);
            }
            HID_DeInit();
            KillDisThread();

            TerminateThread(m_Thread, -1 );
            m_Thread = NULL;
            m_FunctionResult = FAIL;
            return m_FunctionResult;
        }

    }
    Sleep(50);
    HID_DeInit();
    KillDisThread();

    if (m_pstdownloadinfo->porttype == COM)
    {
        CloseHandle(m_pstdownloadinfo->comphandle);
        m_pstdownloadinfo->comphandle = NULL;
    }
    delete[] m_pstdownloadinfo->buffer;
    m_pstdownloadinfo->buffer = NULL;


    wprintf(L"Megawin: %d bytes of flash written\r\n", m_pstdownloadinfo->buffersize);

    return m_FunctionResult;
}

void Megawin_UploadClass::KillDisThread()
{
    if (m_UseDlg != 0)
    {
        SendMessage(g_cDisDlg.m_hWnd, WM_SYSCOMMAND, SC_CLOSE, 0);
        PostMessage(g_cDisDlg.m_hWnd, WM_CLOSE, 0, 0);
        PostMessage(g_cDisDlg.m_hWnd, WM_DESTROY, 0, 0);

        while (m_isDisTheadRun == 1)
        {
            Sleep(500);
        }

        if ((m_DisThread == NULL) && (m_isDisTheadRun == 1))
        {
            TerminateThread(m_DisThread, -1);
        }
        m_DisThread = NULL;
    }
}


DWORD WINAPI ThreadUpdateRun(LPVOID pParam)
{
    Megawin_UploadClass* dlg = (Megawin_UploadClass*)pParam;
    dlg->m_FunctionResult = UpdateMCU( dlg->m_pstdownloadinfo, FALSE );
    dlg->m_isTheadRun     = FALSE;
    return 0;
}

