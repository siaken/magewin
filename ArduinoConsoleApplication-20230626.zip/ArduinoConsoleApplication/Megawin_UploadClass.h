#pragma once

#include <iostream>

#define _AFX_ALL_WARNINGS

#include <afxwin.h>
#include <afxext.h> 

#include "COM_ISP32_Library.h"


class Megawin_UploadClass
{
public:
    Megawin_UploadClass();
    ~Megawin_UploadClass();

    void  HID_SendResetCMD();
    void  HID_DeInit();
    DWORD HID_CreateDevice(WORD VID, WORD PID);

    int BodyInit(LPCSTR Filename, LPCSTR MCUname, LPCSTR PortName);
    int LoadUploadFile(LPCSTR Filename);
    int DumpInfo();
    int UpdateTarget();

    void KillDisThread();

    BODYINFO*      m_pstbodyinfo;
    UINT	       m_bodycount;
    DOWNLOADINFO*  m_pstdownloadinfo;
    DWORD          m_loadfileaddress;

    CString        m_loadFileName;
    CString        m_MCUName;
    CString        m_PortName;


    BOOL           m_isTheadRun;
    WORD           m_FunctionResult;
    HANDLE         m_Thread;

    BOOL           m_UseDlg;
    HANDLE         m_DisThread;
    BOOL           m_isDisTheadRun;

};


DWORD WINAPI ThreadUpdateRun(LPVOID pParam);
