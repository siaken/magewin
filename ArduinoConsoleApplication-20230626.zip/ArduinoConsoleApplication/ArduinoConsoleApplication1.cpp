﻿// ArduinoConsoleApplication1.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>




#define _AFX_ALL_WARNINGS

#include <afxwin.h>
#include <afxext.h> 

//#include "COM_ISP32_Library.h"
#include "Megawin_UploadClass.h"
#include "CMFCApplicationWinApp.h"

#include "cdispp.h"
#include "resource.h"

/*
#include <afxdisp.h> 

#ifndef _AFX_NO_OLE_SUPPORT
#include <afxdtctl.h> 
#endif
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h> 
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <afxcontrolbars.h> 
*/


DWORD Hex2Bin(LPVOID &pHexData)
{
#define a2n(c) (((c) & 0x0f) + (((c) & 0x40) ? 9 : 0))
#pragma pack(push)
#pragma pack(1)
	struct
	{
		BYTE cnt;
		WORD addr;
		BYTE tag;
		BYTE dat[256];
	}hdb;
#pragma pack(pop)
	DWORD last(0);
	DWORD offset(0);
	LPBYTE dump;
	PCHAR seps = (PCHAR)"\n\r";
	PCHAR token;
	PCHAR next_token;
	BOOL end = FALSE;
	BYTE sum;
	
	dump = (LPBYTE)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, 64*1024);
	memset(dump, 0xff, 64*1024);
	token = strtok_s((PCHAR)pHexData, seps, &next_token);
	while (!end && token)
	{
		if (*token++ == ':')
		{
			sum = 0;
			for (int i=0; token[i]; i+=2)
			{
				sum += (((BYTE *)&hdb)[i/2] = BYTE((a2n(token[i]) << 4) + a2n(token[i+1])));
			}
			if (sum != 0) break;
			__asm
			{
				mov ax, hdb.addr
				mov cl, ah
				mov ch, al
				mov hdb.addr, cx
			}
			switch (hdb.tag)
			{
			case 0:
				memcpy(dump+hdb.addr+offset, hdb.dat, hdb.cnt);
				last = max(last, DWORD(hdb.addr+offset+hdb.cnt));
				break;
			case 2:
			case 4:
				if ((hdb.cnt == 2) && (hdb.addr == 0))
				{
					offset = MAKEWORD(hdb.dat[1], hdb.dat[0]) << (1 << hdb.tag);
					dump = (LPBYTE)HeapReAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, dump, offset+64*1024);
				}
				break;
			case 1:
			default:
				end = TRUE;
				break;
			}
		}
		token = strtok_s(NULL, seps, &next_token);
	}
	HeapFree(GetProcessHeap(), 0, pHexData);
	pHexData = HeapReAlloc(GetProcessHeap(), 0, dump, last);
	return last;
}




int main(int argc, char* argv[])
{
    BOOL     UseDlg;
    char  strPort[256] = { 0 };
    char  strFile[256] = { 0 };
    char  strMCU[256] = { 0 };
    char* lp;

    int i,  len;
    wprintf( L"\r\n" );
    //回显命令行，便于调试
    //printf("[%d]:", argc);
    for (i = 0; i < argc; i++)
    {
        printf( argv[i] );
        wprintf( L" " );
    }
    wprintf(L"\r\n");

    wprintf(L"Megawin Arduino ISP upload.\r\n");

/*
    ///分段显示
    for (i = 0; i < argc; i++)
    {
        printf("[%d]: %s \r\n", i, argv[i] );
    }
    printf("\r\n");
*/

    ///解析字段
    ///[0] :MegawinAISP.exe
    ///[1]: -i
    ///[2] : -d
    ///[3] : --port = COM4
    ///[4] : -U
    ///[5] : true
    ///[6] : -pMG32F02U128
    ///[7] : -i
    ///[8] : -e
    ///[9] : -w
    ///[10] : -v  
    ///[11] : C : \Users\11022\AppData\Local\Temp\arduino - sketch - 23947195BCF2838BC191E9B379EA7D95 / abc.ino.bin
    ///[12]: -R

    for (i = 0; i < argc; i++)
    {
        //get port
        if (strncmp("-v", argv[i], 2) == 0)
        {
            UseDlg = 1;
        }

        //get port
        if (strncmp("--port", argv[i], 6) == 0)
        {
            len = strlen( argv[i] );
            lp = strchr( argv[i], '=' );
            do
            {
                lp++;
                if(  (*lp != 0x20) )
                {
                    break;
                }
            } while(*lp != '\0' );
            strcpy_s( strPort, lp );
        }

        //get MCU
        lp = strstr(argv[i], "-p" );
        if (lp != NULL)
        {
            lp++;
            do
            {
                lp++;
                if (( *lp != 0x20))
                {
                    break;
                }
            } while ((*lp !=  '\0'));
            strcpy_s( strMCU, lp);
        }

        //get bin file
        if( strstr( argv[i], ".bin" ) != NULL )
        {
            strcpy_s( strFile, argv[i] );
        }
    }
    //printf("\r\n");
    //printf("strPort:[%s] \r\n", strPort);
    //printf("strMCU:[%s] \r\n", strMCU);
    //printf("strFile:[%s] \r\n", strFile);

/*
    //for test
    strcpy_s(strMCU,  "MG32F02U128");
    strcpy_s(strPort, "COM4");
    strcpy_s(strFile, "C:/Users/11022/AppData/Local/Temp/arduino-sketch-23947195BCF2838BC191E9B379EA7D95/abc.ino.bin");
*/

    if ((strlen(strFile) == 0)
     || (strlen(strMCU) == 0)
     || (strlen(strPort) == 0))
    {
        wprintf( L"Error! Load command error.\r\n");
        return -1;
    }

/*
    //字符转换
    WCHAR wsrtFileName[512] = {0};
    WCHAR wsrtMCU[512] = { 0 };
    WCHAR wsrtPort[512] = { 0 };

    MultiByteToWideChar( CP_ACP, 0,
                         strFile,  strlen(strFile),
                         wsrtFileName, 512);
    MultiByteToWideChar( CP_ACP, 0,
                         strMCU, strlen(strMCU),
                         wsrtMCU, 512);
    MultiByteToWideChar( CP_ACP, 0,
                         strPort, strlen(strPort),
                         wsrtPort, 512);

    wprintf(_T("ww: %s \r\n"), wsrtFileName);
    wprintf(_T("ww: %s \r\n"), wsrtMCU);
    wprintf(_T("ww: %s \r\n"), wsrtPort);
*/

    Megawin_UploadClass  upclass;

    upclass.m_UseDlg = UseDlg;

    upclass.BodyInit(strFile, strMCU, strPort);

    int iRet = upclass.UpdateTarget();
    if(  (0 != iRet) 
      && (SUCCESS != iRet)
      && (USER_STOP != iRet) )
    {
        wprintf(L"Update target failed!  ErrorCode=%d\r\n",  iRet );
        return -1;
    }
    wprintf(L"Megawin ISP upload done. Thank you.\r\n");

    return 0;
}



