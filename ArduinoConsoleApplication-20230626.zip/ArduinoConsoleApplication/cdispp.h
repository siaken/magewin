﻿#pragma once
#include "afxdialogex.h"

#define WM_MYMESSAGE_UPLEVEL (WM_USER + 101)
#define WM_MYMESSAGE_DOWNLEVEL (WM_USER + 102)


// cdispp 对话框

class cdispp : public CDialogEx
{
	DECLARE_DYNAMIC(cdispp)

public:
	cdispp(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~cdispp();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

	afx_msg LRESULT  OnUpLevel(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT  OnDownLevel(WPARAM wParam, LPARAM lParam);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	CStatic m_DisString;
};
